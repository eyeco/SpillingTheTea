# sqıd Visual Programming Environment

sqıd is a visual programming (VP) based tool for data flow processing, mainly targeted for rapid prototyping and ad-hoc experimentation in UI research sceanrios. For more details see the [project page on the author's webpage](https://www.rolandaigner.com/sub/sqid.html), the [repository on Github](https://github.com/eyeco/sqid), and the [publication in the IEEE Pervasive Computing magazine](https://doi.org/10.1109/MPRV.2025.3627401) (Open Access).

## Author

Roland Aigner [[link](https://www.rolandaigner.com)]

## License

Copyright (C) 2026 eyeco

sqid Visual Programming Environment is licensed under the GPL3 License. See the sqıd project [LICENSE](https://github.com/eyeco/sqid/blob/main/LICENSE) file, (also contained in this archive).